# 設計

## 3 Options

| Option | 内容 | 判断 |
| --- | --- | --- |
| A | CLI中心 | 自動化は容易だが利用者導線が弱い |
| B | Product spec + CLI | 自動検証と手動確認を分離できる |
| C | Docsのみ | 実装価値が弱い |

## Chosen

Option B。理由: サムネイル、階層、検索条件を同じ画面で扱う。
